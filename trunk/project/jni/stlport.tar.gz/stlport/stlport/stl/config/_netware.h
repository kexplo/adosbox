#define _STLP_PLATFORM "Novell Netware"
