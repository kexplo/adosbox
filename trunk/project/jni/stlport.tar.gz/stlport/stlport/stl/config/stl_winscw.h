#ifndef _STLP_WINSCW_H
#define _STLP_WINSCW_H

#define _STLP_COMPILER "WINSCW"

#undef __MWERKS__

//==========================================================

#  define _STLP_WCHAR_T_IS_USHORT 1
#  define _STLP_LONG_LONG long long

//==========================================================

#endif
